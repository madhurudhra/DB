# -*- coding: utf-8 -*-
import os
import sys
import time
import json
import logging
import threading
import smtplib
import re
from email.message import EmailMessage
from datetime import datetime
import robin_stocks.robinhood as r

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] (%(threadName)s) %(message)s',
    stream=sys.stdout
)

ACCOUNT_FILE = "/var/lib/stock-bot/stock_account.json"
STOP_LOSS_PCT = 0.01          # 1.0% Absolute Stop-Loss
TAKE_PROFIT_PCT = 1.00         # 6.0% Target Profit Ceiling
STATE_LOCK = threading.Lock()

def load_secure_env():
    try:
        from cryptography.fernet import Fernet
        enc_path = '/opt/stock-bot/.env.enc'
        key_path = '/opt/stock-bot/.secret.key'
        if os.path.exists(enc_path) and os.path.exists(key_path):
            with open(key_path, 'rb') as kf: key = kf.read().strip()
            with open(enc_path, 'rb') as ef: enc_data = ef.read()
            cipher = Fernet(key)
            decrypted = cipher.decrypt(enc_data).decode('utf-8')
            for line in decrypted.splitlines():
                if line.strip() and not line.startswith('#') and '=' in line:
                    k, v = line.strip().split('=', 1)
                    os.environ[k.strip()] = v.strip().strip('\"').strip("'")
            logging.info("[STOCK-BOT] Password credentials file decrypted and loaded successfully.")
            return True
    except Exception as e:
        logging.error(f"[STOCK-BOT ERROR] Secure decryption module failed: {e}")
    return False

def load_stored_account():
    if not os.path.exists(ACCOUNT_FILE):
        return {"positions": {}}
    try:
        with open(ACCOUNT_FILE, "r") as f:
            return json.load(f)
    except Exception as e:
        logging.error(f"[LEDGER] Failed to read account json matrix: {e}")
        return {"positions": {}}

def save_hardened_account(account_data):
    try:
        os.makedirs(os.path.dirname(ACCOUNT_FILE), exist_ok=True)
        temp_path = ACCOUNT_FILE + ".live_exit.tmp"
        with open(temp_path, "w") as f:
            json.dump(account_data, f, indent=2)
        os.replace(temp_path, ACCOUNT_FILE)
    except Exception as e:
        logging.error(f"[LEDGER ERROR] File lock preservation failure: {e}")

def authenticate_robinhood():
    try:
        token_dir = "/opt/stock-bot/.tokens"
        os.environ["ROBINHOOD_OAUTH_TOKEN_DIR"] = token_dir
        os.makedirs(token_dir, exist_ok=True)
        
        user = os.getenv("ROBINHOOD_USERNAME")
        password = os.getenv("ROBINHOOD_PASSWORD")
        mfa_code = os.getenv("ROBINHOOD_MFA_SECRET")
        
        if user and password:
            r.login(username=user, password=password, expiresIn=86400, mfa_code=mfa_code)
            return True
        return False
    except Exception as e:
        logging.error(f"[BROKERAGE AUTH CRITICAL] Handshake failed: {e}")
        return False

def send_email_notification(subject, html_content):
    try:
        host = os.environ.get("SMTP_SERVER", "://gmail.com").strip()
        port = int(os.environ.get("SMTP_PORT", "587").strip())
        user = os.environ.get("ALERT_EMAIL_FROM", "").strip()
        password = os.environ.get("ALERT_EMAIL_PASSWORD", "").strip()
        recipient = os.environ.get("ALERT_EMAIL_TO", "").strip()
        
        if not all([host, user, password, recipient]):
            return
            
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = user
        msg["To"] = recipient
        
        plain_text = re.sub(r"<[^>]+>", " ", html_content)
        msg.set_content(re.sub(r"\s+", " ", plain_text).strip() or subject)
        msg.add_alternative(html_content, subtype="html")
        
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.ehlo()
            smtp.login(user, password)
            smtp.send_message(msg)
        logging.info(f"[NOTIFICATION] Automated alert sent successfully: {subject}")
    except Exception as e:
        logging.error(f"[NOTIFICATION ERROR] Email handshake failed: {e}")

def synchronize_and_protect_portfolio():
    if not authenticate_robinhood():
        logging.error("[SYNC ENGINE] Brokerage authentication rejected. Retrying cycle...")
        return

    with STATE_LOCK:
        local_data = load_stored_account()
        stored_positions = local_data.get("positions", {})

        try:
            rh_portfolio = r.build_holdings()
            if rh_portfolio is None:
                logging.warning("[ROBINHOOD API] Build holdings returned None content array.")
                return
        except Exception as e:
            logging.error(f"[API NETWORK ERROR] Failed to query active holdings structure: {e}")
            return

        active_symbols = list(rh_portfolio.keys())
        cleaned_positions = {}

        # Reconcile Ghost Blocks cleanly (Drops RNXT and SPCX traces if missing from portfolio)
        for symbol, position_meta in stored_positions.items():
            if symbol in rh_portfolio:
                cleaned_positions[symbol] = position_meta
            else:
                logging.warning(f"[RECONCILED GHOST] Dropped tracking loop for stale asset: {symbol}")

        # Core evaluation logic loop
        for symbol in active_symbols:
            rh_meta = rh_portfolio[symbol]
            current_price = float(rh_meta.get('price', 0.0))
            
            if symbol in cleaned_positions and float(cleaned_positions[symbol].get('average_buy_price', 0.0)) > 0:
                original_cost = float(cleaned_positions[symbol]['average_buy_price'])
            else:
                original_cost = float(rh_meta.get('average_buy_price', current_price))
                logging.info(f"[LEDGER INITIALIZED] Locked original entry cost basis for {symbol} at: ${original_cost:.4f}")

            net_pnl_pct = (current_price - original_cost) / original_cost if original_cost > 0 else 0.0 if original_cost > 0 else 0.0
            calculated_stop_threshold = original_cost * (1.0 - STOP_LOSS_PCT)
            calculated_target_ceiling = original_cost * (1.0 + TAKE_PROFIT_PCT)

            cleaned_positions[symbol] = {
                "average_buy_price": original_cost,
                "quantity": float(rh_meta.get('quantity', 1.0)),
                "last_tracked_price": current_price,
                "hard_stop_loss": calculated_stop_threshold,
                "take_profit_target": calculated_target_ceiling
            }

            logging.info(
                f"[TRACKING] {symbol:<6} | True Net P&L: {net_pnl_pct*100:+.2f}% | "
                f"Price: ${current_price:.2f} | Entry Cost: ${original_cost:.2f} | "
                f"Stop Guard: ${calculated_stop_threshold:.2f} | Target: ${calculated_target_ceiling:.2f}"
            )

            if original_cost <= 0:
                logging.warning(f"[PROTECTION ACTIVE] Skipping risk checks for {symbol}: Entry cost basis is uninitialized or zero!")
                continue
            elif current_price <= calculated_stop_threshold:
                logging.warning(f"[🚨 RISK BREACH] True 1.0% Stop-Loss Hit on {symbol}! Routing immediate liquidation order.")
                r.order_sell_market(symbol, cleaned_positions[symbol]["quantity"])
                subject = f"[STOCK-BOT] EMERGENCY EXIT: {symbol}"
                html = f"<h3>Live Drawdown Liquidation Report</h3><p><b>Symbol:</b> {symbol}</p><p><b>Execution Price:</b> ${current_price:.2f}</p><p><b>Reason:</b> 1.0% Hard Stop Breached.</p>"
                threading.Thread(target=send_email_notification, args=(subject, html), daemon=True).start()
                # Maintained tracking profile natively until position updates to zero
                
            elif current_price >= calculated_target_ceiling:
                logging.info(f"[📈 PROFIT CEILING] Take-Profit reached for {symbol}. Harvesting alpha gains.")
                r.order_sell_market(symbol, cleaned_positions[symbol]["quantity"])
                subject = f"[STOCK-BOT] TARGET TAKE-PROFIT: {symbol}"
                html = f"<h3>Target Profit Trajectory Met</h3><p><b>Symbol:</b> {symbol}</p><p><b>Execution Price:</b> ${current_price:.2f}</p>"
                threading.Thread(target=send_email_notification, args=(subject, html), daemon=True).start()
                # Maintained tracking profile natively until position updates to zero

        local_data["positions"] = cleaned_positions
        save_hardened_account(local_data)

# --- BACKWARD COMPATIBILITY BRIDGE LAYERS ---
def check_live_position():
    synchronize_and_protect_portfolio()

if __name__ == "__main__":
    logging.info("[STARTUP] Launching Live Autonomous Portfolio Supervision Loop...")
    load_secure_env()
    while True:
        try:
            synchronize_and_protect_portfolio()
        except Exception as global_err:
            logging.error(f"[CORE EXCEPTION LAYER] Telemetry cycle recovered from fatal drop: {global_err}")
        time.sleep(15)
