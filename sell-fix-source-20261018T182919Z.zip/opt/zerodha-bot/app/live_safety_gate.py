from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, ROUND_DOWN
from pathlib import Path
from zoneinfo import ZoneInfo


IST = ZoneInfo("Asia/Kolkata")

STATE_DIR = Path("/opt/zerodha-bot/state")
AUDIT_FILE = STATE_DIR / "live_order_audit.jsonl"


class LiveSafetyError(Exception):
    pass


@dataclass(frozen=True)
class LiveOrderIntent:
    symbol: str
    exchange: str
    transaction_type: str
    product: str
    order_type: str
    quantity: int
    limit_price: Decimal
    strategy: str
    signal_id: str


@dataclass(frozen=True)
class ValidatedLiveOrder:
    intent: LiveOrderIntent
    order_key: str
    notional_inr: Decimal


def _env_decimal(name: str, default: str) -> Decimal:
    try:
        value = Decimal(os.getenv(name, default))
    except Exception:
        raise LiveSafetyError("Invalid numeric risk setting: " + name) from None
    if not value.is_finite() or value <= 0:
        raise LiveSafetyError("Risk setting must be positive and finite: " + name)
    return value


def _audit(
    decision: str,
    intent: LiveOrderIntent,
    reason: str,
    order_key: str,
):
    STATE_DIR.mkdir(parents=True, exist_ok=True)

    now = datetime.now(IST)

    record = {
        "timestamp_ist": now.isoformat(),
        "date_ist": now.date().isoformat(),
        "decision": decision,
        "intent": {
            "symbol": intent.symbol,
            "exchange": intent.exchange,
            "transaction_type": intent.transaction_type,
            "product": intent.product,
            "order_type": intent.order_type,
            "quantity": intent.quantity,
            "limit_price": str(intent.limit_price),
            "strategy": intent.strategy,
            "signal_id": intent.signal_id,
        },
        "notional_inr": str(
            intent.limit_price * Decimal(intent.quantity)
        ),
        "order_key": order_key,
        "reason": reason,
    }

    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(
            json.dumps(
                record,
                separators=(",", ":"),
            )
            + "\n"
        )


def _order_key(intent: LiveOrderIntent) -> str:
    raw = "|".join(
        [
            intent.symbol,
            intent.exchange,
            intent.transaction_type,
            intent.product,
            intent.order_type,
            str(intent.quantity),
            str(intent.limit_price),
            intent.strategy,
            intent.signal_id,
        ]
    )

    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def validate_live_order(
    intent: LiveOrderIntent,
    quote_price: Decimal,
    tick_size: Decimal,
    broker_available_margin: Decimal,
    broker_reconciled: bool,
) -> ValidatedLiveOrder:

    if type(intent.quantity) is not int or intent.quantity <= 0:
        raise LiveSafetyError("Quantity must be a positive integer")
    for name, value in (("limit_price", intent.limit_price), ("quote_price", quote_price), ("tick_size", tick_size)):
        if not isinstance(value, Decimal) or not value.is_finite() or value <= 0:
            raise LiveSafetyError(name + " must be a positive finite Decimal")
    if not isinstance(broker_available_margin, Decimal) or not broker_available_margin.is_finite() or broker_available_margin < 0:
        raise LiveSafetyError("Broker margin must be a nonnegative finite Decimal")
    if broker_reconciled is not True:
        raise LiveSafetyError("Broker reconciliation must be explicitly true")
    key = _order_key(intent)

    def block(reason: str):
        # RESTORE_FAIL_CLOSED_SAFETY_V2: rejected intents must never reach the broker.
        raise LiveSafetyError("Live order blocked: " + reason)

    mode = os.getenv(
        "TRADING_MODE",
        "PAPER",
    ).strip().upper()

    if mode != "LIVE":
        block(
            "TRADING_MODE must be LIVE"
        )

    acknowledgement = os.getenv(
        "LIVE_TRADING_ENABLED",
        "",
    ).strip()

    if acknowledgement != "YES_I_UNDERSTAND":
        block(
            "LIVE_TRADING_ENABLED acknowledgement is absent"
        )

    if os.getenv(
        "KILL_SWITCH",
        "false",
    ).strip().lower() == "true":
        block(
            "KILL_SWITCH is enabled"
        )

    allowed_raw = os.getenv(
        "LIVE_ALLOWED_SYMBOLS",
        "",
    ).strip()

    if not allowed_raw:
        block(
            "LIVE_ALLOWED_SYMBOLS is empty"
        )

    allowed = {
        item.strip().upper()
        for item in allowed_raw.split(",")
        if item.strip()
    }

    symbol = intent.symbol.strip().upper()

    if symbol not in allowed:
        block(
            f"{symbol} is not allowlisted"
        )

    if intent.exchange.upper() != "NSE":
        block(
            "only NSE exchange is permitted"
        )

    if intent.transaction_type.upper() not in {
        "BUY",
        "SELL",
    }:
        block(
            "only BUY or SELL is permitted"
        )

    if intent.product.upper() != "CNC":
        block(
            "only CNC product is permitted"
        )

    if intent.order_type.upper() != "LIMIT":
        block(
            "only LIMIT orders are permitted"
        )

    if intent.quantity <= 0:
        block(
            "quantity must be positive"
        )

    if intent.limit_price <= 0:
        block(
            "limit price must be positive"
        )

    if quote_price <= 0:
        block(
            "quote price must be positive"
        )

    if tick_size <= 0:
        block(
            "tick size must be positive"
        )

    ticks = (
        intent.limit_price / tick_size
    ).quantize(
        Decimal("1"),
        rounding=ROUND_DOWN,
    )

    aligned = ticks * tick_size

    if aligned != intent.limit_price:
        block(
            f"limit price {intent.limit_price} is not aligned "
            f"to tick size {tick_size}"
        )

    deviation = abs(
        intent.limit_price - quote_price
    ) / quote_price

    max_deviation = _env_decimal(
        "LIVE_MAX_PRICE_DEVIATION",
        "0.005",
    )

    if deviation > max_deviation:
        block(
            f"limit price deviation "
            f"{deviation * 100:.4f}% exceeds configured "
            f"threshold {max_deviation * 100:.4f}%"
        )

    notional = (
        intent.limit_price
        * Decimal(intent.quantity)
    )

    max_order = _env_decimal(
        "LIVE_MAX_ORDER_VALUE_INR",
        "100",
    )

    if notional > max_order:
        block(
            f"₹{notional:.2f} exceeds per-order cap "
            f"₹{max_order:.2f}"
        )

    if not broker_reconciled:
        block(
            "broker orders, positions, and margins are not reconciled"
        )

    if broker_available_margin < notional:
        block(
            f"available broker margin "
            f"₹{broker_available_margin:.2f} "
            f"is below order value "
            f"₹{notional:.2f}"
        )

    if os.getenv(
        "LIVE_ORDER_LOCK",
        "false",
    ).strip().lower() == "true":
        block(
            "LIVE_ORDER_LOCK is enabled"
        )

    # IMPORTANT:
    #
    # Validation does NOT:
    #   - submit an order
    #   - write ALLOW
    #   - consume daily limits
    #   - create a committed deduplication record
    #
    # The executor performs those actions only after
    # confirmed broker acceptance.

    return ValidatedLiveOrder(
        intent=intent,
        order_key=key,
        notional_inr=notional,
    )


def audit_commit(
    validated: ValidatedLiveOrder,
    broker_order_id: str,
):
    _audit(
        "ALLOW",
        validated.intent,
        (
            "broker accepted order; "
            f"broker_order_id={broker_order_id}"
        ),
        validated.order_key,
    )


def audit_failed(
    validated: ValidatedLiveOrder,
    reason: str,
):
    _audit(
        "FAILED",
        validated.intent,
        reason,
        validated.order_key,
    )
