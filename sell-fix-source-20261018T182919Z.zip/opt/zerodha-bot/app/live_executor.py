from __future__ import annotations

import json
import os
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from kiteconnect import KiteConnect
from buy_control_store import BuyBlocked, submission_guard

from live_reconciliation import reconcile_live_broker
from live_safety_gate import (
    LiveOrderIntent,
    LiveSafetyError,
    audit_commit,
    audit_failed,
    validate_live_order,
)


STATE_DIR = Path("/opt/zerodha-bot/state")
LOCK_FILE = STATE_DIR / "LIVE_ORDER_LOCK.json"


class LiveExecutionError(Exception):
    pass


def _load_env() -> None:
    env_file = Path(
        "/opt/zerodha-bot/.env"
    )

    if not env_file.exists():
        return

    for raw in env_file.read_text(
        encoding="utf-8"
    ).splitlines():

        line = raw.strip()

        if (
            not line
            or line.startswith("#")
            or "=" not in line
        ):
            continue

        key, value = line.split(
            "=",
            1,
        )

        key = key.strip()
        value = value.strip()

        if (
            len(value) >= 2
            and value[0] == value[-1]
            and value[0] in {"'", '"'}
        ):
            value = value[1:-1]

        os.environ.setdefault(
            key,
            value,
        )


def _set_lock(reason: str) -> None:
    STATE_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    payload = {
        "locked": True,
        "timestamp": datetime.now().astimezone().isoformat(),
        "reason": reason,
    }

    LOCK_FILE.write_text(
        json.dumps(
            payload,
            indent=2,
        ),
        encoding="utf-8",
    )


def _is_locked() -> bool:
    return LOCK_FILE.exists()


def _fresh_reconciliation() -> dict:
    result = reconcile_live_broker()

    if not result.get(
        "reconciled",
        False,
    ):
        raise LiveExecutionError(
            "Fresh broker reconciliation failed"
        )

    if result.get(
        "open_orders"
    ):
        raise LiveExecutionError(
            "Existing broker open orders detected; "
            "live order blocked"
        )

    if result.get(
        "net_positions"
    ):
        raise LiveExecutionError(
            "Existing broker positions detected; "
            "live order blocked"
        )

    return result


def _get_broker_margin() -> Decimal:
    api_key = os.getenv(
        "KITE_API_KEY",
        "",
    ).strip()

    access_token = os.getenv(
        "KITE_ACCESS_TOKEN",
        "",
    ).strip()

    if not api_key or not access_token:
        raise LiveExecutionError(
            "Kite credentials are missing"
        )

    kite = KiteConnect(
        api_key=api_key
    )

    kite.set_access_token(
        access_token
    )

    margins = kite.margins()

    equity = {}

    if isinstance(
        margins,
        dict,
    ):
        equity = margins.get(
            "equity",
            {},
        )

    available = {}

    if isinstance(
        equity,
        dict,
    ):
        available = equity.get(
            "available",
            {},
        )

    if not isinstance(
        available,
        dict,
    ):
        raise LiveExecutionError(
            "Broker available-margin response is invalid"
        )

    live_balance = available.get(
        "live_balance"
    )

    if live_balance is None:
        raise LiveExecutionError(
            "Broker live_balance is unavailable"
        )

    return Decimal(
        str(live_balance)
    )


def submit_live_order(
    intent: LiveOrderIntent,
    quote_price: Decimal,
    tick_size: Decimal,
) -> dict:

    _load_env()

    if os.getenv(
        "TRADING_MODE",
        "PAPER",
    ).strip().upper() != "LIVE":
        raise LiveExecutionError(
            "Live executor refused: "
            "TRADING_MODE is not LIVE"
        )

    if os.getenv(
        "LIVE_TRADING_ENABLED",
        "",
    ).strip() != "YES_I_UNDERSTAND":
        raise LiveExecutionError(
            "Live executor refused: "
            "acknowledgement missing"
        )

    if os.getenv(
        "KILL_SWITCH",
        "false",
    ).strip().lower() == "true":
        raise LiveExecutionError(
            "Live executor refused: "
            "KILL_SWITCH enabled"
        )

    if _is_locked():
        raise LiveExecutionError(
            "Live executor refused: "
            "LIVE_ORDER_LOCK is active"
        )

    # Fresh broker state immediately before validation.
    reconciliation = _fresh_reconciliation()

    broker_margin = _get_broker_margin()

    validated = validate_live_order(
        intent=intent,
        quote_price=quote_price,
        tick_size=tick_size,
        broker_available_margin=broker_margin,
        broker_reconciled=bool(
            reconciliation.get(
                "reconciled",
                False,
            )
        ),
    )

    api_key = os.getenv(
        "KITE_API_KEY",
        "",
    ).strip()

    access_token = os.getenv(
        "KITE_ACCESS_TOKEN",
        "",
    ).strip()

    kite = KiteConnect(
        api_key=api_key
    )

    kite.set_access_token(
        access_token
    )

    try:
        side = validated.intent.transaction_type
        with submission_guard('zerodha', side):
            broker_order_id = kite.place_order(
                variety=kite.VARIETY_REGULAR,
                exchange=validated.intent.exchange,
                tradingsymbol=validated.intent.symbol,
                transaction_type=validated.intent.transaction_type,
                quantity=validated.intent.quantity,
                product=validated.intent.product,
                order_type=validated.intent.order_type,
                price=float(
                    validated.intent.limit_price
                ),
                validity=kite.VALIDITY_DAY,
            )

    except BuyBlocked:
        raise
    except Exception as exc:
        message = str(exc)

        ambiguous_terms = (
            "timeout",
            "timed out",
            "connection",
            "connect",
            "read error",
            "remote",
            "network",
            "broken pipe",
        )

        ambiguous = any(
            term in message.lower()
            for term in ambiguous_terms
        )

        if ambiguous:
            _set_lock(
                "AMBIGUOUS_SUBMISSION: "
                + message
            )

            audit_failed(
                validated,
                "AMBIGUOUS_SUBMISSION: "
                + message,
            )

            raise LiveExecutionError(
                "AMBIGUOUS broker submission. "
                "LIVE_ORDER_LOCK enabled. "
                "DO NOT RETRY. "
                "Fresh broker reconciliation required."
            ) from exc

        audit_failed(
            validated,
            "BROKER_REJECTED: "
            + message,
        )

        raise LiveExecutionError(
            "Broker rejected live order: "
            + message
        ) from exc

    if not broker_order_id:
        _set_lock(
            "Broker returned no order ID "
            "after submission"
        )

        audit_failed(
            validated,
            "AMBIGUOUS_SUBMISSION: "
            "broker returned no order ID",
        )

        raise LiveExecutionError(
            "Broker returned no order ID. "
            "LIVE_ORDER_LOCK enabled. "
            "Fresh reconciliation required."
        )

    # COMMIT ONLY AFTER confirmed broker acceptance.
    audit_commit(
        validated,
        str(broker_order_id),
    )

    return {
        "status": "ACCEPTED",
        "broker_order_id": str(
            broker_order_id
        ),
        "order_key": validated.order_key,
        "notional_inr": str(
            validated.notional_inr
        ),
    }


if __name__ == "__main__":
    print(
        "live_executor.py loaded. "
        "No order is submitted by direct execution."
    )
