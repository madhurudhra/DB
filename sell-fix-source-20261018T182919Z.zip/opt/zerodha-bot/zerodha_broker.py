import os
from typing import Dict, Any, Optional
from kiteconnect import KiteConnect

class ZerodhaStockBroker:
    def __init__(self, api_key: str, access_token: str):
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)

    def get_last_price(self, symbol: str, exchange: str = "NSE") -> float:
        # Zerodha expects instrument keys like "NSE:INFY" or just symbol if quoted with exchange lookup
        instrument_key = f"{exchange}:{symbol}"
        quotes = self.kite.ltp([instrument_key])
        if instrument_key in quotes:
            return float(quotes[instrument_key]['last_price'])
        raise ValueError(f"Unable to fetch price for {symbol}")

    def get_open_position(self, symbol: str) -> Optional[Dict[str, Any]]:
        positions = self.kite.positions()
        # Zerodha splits positions into 'net' and 'day'
        net_positions = positions.get('net', [])
        for pos in net_positions:
            if pos['tradingsymbol'].upper() == symbol.upper() and pos['quantity'] != 0:
                qty = float(pos['quantity'])
                return {
                    "symbol": symbol.upper(),
                    "quantity": abs(qty),
                    "is_long": qty > 0,
                    "shares_available_for_sells": abs(float(pos.get('realised', 0) or qty)), # Adjust based on Kite fields
                    "average_buy_price": float(pos['average_price']),
                }
        return None

    def sell_market(self, symbol: str, quantity: float, exchange: str = "NSE"):
        return self.kite.place_order(
            variety=self.kite.VARIETY_REGULAR,
            exchange=exchange,
            tradingsymbol=symbol,
            transaction_type=self.kite.TRANSACTION_TYPE_SELL,
            quantity=int(quantity),
            product=self.kite.PRODUCT_CNC,  # Delivery / Long term
            order_type=self.kite.ORDER_TYPE_MARKET
        )
