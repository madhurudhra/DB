EQUITY STALE-HOLDING QUOTE RETRY - LIMITED REPAIR

Unzip the package on the VPS, change into its extracted directory, and run:
    sudo /usr/bin/python3 -B install.py
Review the prompt and type yes only if the brief monitoring interruption is acceptable.

Exact expected existing SHA256:
c66f43d9d433e2ceafc45774e34eed71d1b207fa4714132124ec6b0b0c5f797c
New SHA256:
4c97b441275aa09e044f77084743ae95a82157aa297f12f55fc446907ab291cb

Behavior:
* After normal collection, retry only managed holdings rejected as STALE_QUOTE.
* At most ONE extra schema-bounded quote batch per collection pass.
* Five-second asyncio request timeout, no sleeps; cancellation/transport cleanup may take longer.
* If the schema cannot fit all stale holdings, rotate which subset is retried.
* Strictly retain symbol identity, duplicates, active state, has_traded, finite positive
  bid/ask and original timestamp range (-2 through 10 seconds) validation.
* Validated recovered quotes enter the ORIGINAL sampling/scoring pass once.
* Invalid/stale/missing responses remain blocked. No stale-price fallback.
* Existing submission revalidation remains unchanged.

LIMITATIONS:
This can recover a transient stale read; it cannot make a venue publish quotes.
It does not guarantee full portfolio recovery, execution coverage, or resolve extended-hours
liquidity/data limitations. Normal collection may still contain quotes that age while other
requests run; the existing final submission checks are not removed by this patch.
This is NOT the larger 10% cash / dual-risk / ATR / daily-indicator strategy update.
Normal live trading may resume when the service starts with its existing permissions.
The installer checks local intents, not broker-side open orders. It refuses pending local
intents and queued controls, backs up source, asks approval, stops only this service,
rechecks while stopped, atomically replaces source, then starts the service.
No broker tools are invoked by the installer. Runtime OAuth behavior remains unchanged.
No tokens, credentials, configuration, database, account numbers or live orders are packaged.

VALIDATION PERFORMED HERE:
Source SHA256 verified; full updated source and installer compiled without execution;
AST comparison confirms only collector and its cycle call changed.
No runtime integration tests, simulated trades, broker calls or VPS deployment performed.
Inspect changes.diff before approving. Service active is NOT proof the repair succeeded.

If startup fails, do not repeatedly restart or automatically roll back. Inspect the reported
backup, current service status and pending intents before recovery. The installer does not
silently overwrite newer code or automatically revert trading state.
