#!/usr/bin/env python3
"""Verified-source Equity quote retry installer; no broker/order calls."""
import ast, base64, hashlib, json, os, sqlite3, subprocess, tempfile, zlib
from datetime import datetime, timezone
from pathlib import Path

UNIT = "si-equity-buy-worker.service"
SOURCE = Path("/opt/si-equity-buy-worker/equity_worker.py")
BEFORE = "c66f43d9d433e2ceafc45774e34eed71d1b207fa4714132124ec6b0b0c5f797c"
AFTER = "4c97b441275aa09e044f77084743ae95a82157aa297f12f55fc446907ab291cb"
PAYLOAD = 'c-rlKYjfMkvFLaG3M^8$OxO@5d9#~y7{gl>1>3BZNQI>A_3Eln5D7|%NP-4H*;>c{{dD&{Far!g%HCvi?#-qmgTOp{dipipJ+^I+^Kdl_7s)EJ{12Nrf3Q9#>0OkztwCZf;`_)7r+J*LGAmhG@p7G{dD|LCku~zWCuhEO9nF(8vNl=NwrzWF?@!jaANYT}=uh4U-NB?E^xj;I2Ep5-JyzKYS9u&vZ#U^GxIePO%nGtNC|>UE&7wKIo8Cs#JLOAjcI{f(!}2;=xK@0#f^LH}ntKBnyVKdT;J-Y5U=R48-fo+k)7qH$qqF{?d#bkPQ1$53G+O877W@^of4oShchL+79;IoL7X77RoJAJ@-pcZ{MFkwkny1N<mEPk3n)G`=`=j8^@bqM?z$Sah1VnC=#ViZp#h&)7y$<u+cD%}>G;bZc){}!|ogZYIb(HSMt2|mP;+tqSjrM0@c6*(K>FkLkTF+w`S<2fgV4tVqEMjl><RYav>oCnC`8#`9P2)uToF>rKr+g7#i#PM>Dqn~n>>v2r-sExdc9pH8X)b>LJxf;NImsjhJ}lxq`o0+QQjTG>iD!ER%2}94_=R^Qf4fxvH^2v8E}F*6a3PAFu%E6q8eR-ef|KF90V{_vh0%&~=kSw#*rW@bMH+qBM46bEHDW(q>pV?9J-mVavxrjHy57W#S&*!w75;iNnVgTJS)9U@c@fqo4liEK6VckQ@VgJcB?RIiqKz12QI_G(Q`Snn+S_~UkH-Ds!164c72jw3b{~*9N(lvy>^*_vQ0%ikj~9z*X1kU>4dJ`^kw$-qF|y}*81uLHNjzgufCzaUE*1{~YXG)MmIp->U-tH<i!jS1>W?-nTnC@9pY4w|d}lj*wOL+AY3rVUi04+E0cPabT<ad7m?R6QZd2LE!{Mpl9R!1mvtxf`JJnskf~oR_ragG?Xj|H+e*lEEfouEe58if9`zNv=zJ<k*S4nQI+HnRDSpmAX>IXa+4qo*K{fVy+IgN6lC>E!7F#F|NG{Qd#oNlj@k1c`Lu%D(5^qT<9U50tfVfDis0A0A)2r@VW7|8lK@}dS61B6~LLV&mZD=zS}!^6(uq0IpW)0?&P-x!K!7E;&R*-iRq{&><oI}h;b*WthqMo9Zd{)s-(R{eCWeQV~l^CS-!fZjk^W|^2*8r^IbVH$jlS2L)_XZI)TO`PRP8c$(s&o?V#Pu412Mt_Bc`Do?0k#+bZ%xM2P&dZ9BY#$`)EJ`ibQrpZd#O7-Ahkzg~r_N?FNjFiMN63m}_Q2uODc5}!E`X%6CCgz|rU4Sc7Lp&=QWsEAzi7FJJs0sUl;6U-B5|S`Y-IBp5WVFZK8V8Y<z0r)tu;`B_>*V1Iembo26E&P1A#paU@>f;k1_O;WbOG330Vu9w?6{@!)}=urSLx-dV98kj%ehrHFqtb63NG46|Ov*Dlpd74Eph&J6hFwd%oCYw=MlG_KIw#1)pIatEA-=1>mDVT9~eDDG-QPNSunn0RktSPez{rQ!=dKbjp2gR*QIbN8i|z0P3xP5HjHMjdTrw<t(YKerKE}+2r2Qp~H)|Q<(c4q@^T%P^yiRkD@^IDVlD8T-fKM?(4Izg|od)lU1_GyjK^er?yinnN8Dpowrc1!Vf)=xhB3f=^mf@R{xbX7)~tzm;QJ%w(jm*cOcOGGO^A_{j=`qz4f#I-o0n9u-pLJcmBGqndlytD{I9wt3R0dul<qMT$t<axp%O>rB|@g!^ifDf(v%LCw9xcIu$Opm3qs7NtIslMm}s%aszQz{|dY-O7BA=8KtIjAW`PFrfCG<W+?KW79X$E1jVVCLBI{y>okF_AYbsxjA`l(TPOaj?#1cEdUE*04ez5AD0o8&(NYv;4W&rHr0?4yo&m#IL|MxS)Vws&HIUjeWR#`hjkvk9z27BlY@pq%QrGH2uaiYQEiYS`E~5e`E7L!8=Zgd;UtfR^4R(^;W7A~0j0J@kT=$yMf}1EORpBmr0IC_y!_6XB6%E+x$YYf)J@!xi-o(1MUX6xlupO;;Z~T#O-FZI&-ECnzj?<n;`SccA(K{tdx=2D`e9-RY;gy3l47-Sch>Gsnz}6dOU>eU?#?l{*{m}%WF~pI8D0AVDTR*u!ITlEaJrGGw`@Ko)&aqC0*2Vb=uGZLx!F#~e78{WJ+V^7A1)a|Xp)XN+$KeE&hzA=T&;{3e`V@(QlmH)aiX@1Jx!n;$5AYW(4KLJ6UmEAcsZ^K~0V0y)D6@ol;^=vgm)PBv7?Uy^tY(~y2|r*Dz}%GDy!C1WzzC7Kc_=7wz+_X<E?cyXvO?|!7AM|W-+9)LhZbOPxO!-D5qa%cFFfne0?Ex<1C6w_1`N{Jxc>_%-RHw`f6{;J2V;=SPW^FNB12hW0c^3g4A;CXS2V4m<)06&r&cT5EL-bK6s4}5gXf3VON-t(2R|M<)-&sSDg*_NuHX~=`<JWg>t*<f+BoXKZ-Fhz#}()jAnv15&L@RRXuP_~To^;Rh<}R+U%t3fqUX#OL6Ra!3_I{C+ku>?Si{i?5QO9Rf`|hLnA-{rKfvT&Mp`|goTQgRSGt1bEM9U-U3!ak;gu?Xe6T!NIbGyHojG1{;Zc@*VbQX$*;2z3jpRkSa*cX&>Yo6)3tsi5>_AY2nFvUNESqxzf@5Vw7q`P_`$PT!yRLvN?8KWi$+GgxX_DpIyD!>Yu~p#0_7%?AzTQBi+R$$=si!OJnP+_{e_<W6Z%^0duhg^n_zWQ<OGJxG*BPjzrM?NoFXa&QkER{upPmN(FFoHs83)661OJ3?r{TaZiLfa%ivg%V9EkSyB@-CThQE))-<OkmDjKMR$WzZc+OI3b0n=E90exQuI<k{Syt)|tJb-Bjv}uBI|HRkTxX)SVmNsAJ-s1L?SO${r64W*Xxa|6+b@-*&$eeveE38oLc)@T`f!Tma(#k;bfuTsl#XkU3PlvtkX>bhx{0wC53nx>g4d4i(6!)&}+U>t5@v3G2WYZV}9HD4mn+B0Tg>*=e)X)&d%9((OqD6mTwQO1GnLd(d7N|>Qs$;vwBJdHhH%JW&i)WbK2BfYA*P9v0Ai@1};-^d|axE@$VmS^!d@Kl;`klcjN~h3ZQG&H}X|rB3Sealw%?0^_<)a1#RpPaQJ01N{%XWI*@f*OEU;BgCg4c|LqaT8Ef7J5_6Ny1m@W$0bCL$XY91o=*TPX;`Vx%5KA>@Ar^6aTwoT`;*kW=9qa)#PSG)h}TWqaN8{sa)PH#|G*PtJ-th4*2+2(K3rObB_LN;V0O`&wsQ-40V&S*TIeekvh-U>zMEih=TyFT92^4u(PZZMT1lvUWf#@oG2<V2Gple2~*{9ZpdZ@+<&MAbu9mFAxkk90)U0L|7~r=OMBRSx^+>p8_=Q#=p_r7!t8r>(J(tcqtH2^zSs|6U`tvz5xC<krcUmij+X1#(Y1sKG;6e=7>|1Q-WDebJHFIrC{6-Q0M9YiWGk|eAS=8Z&-hSOzR!IJ!<b!*-;d)?$H*^t*s=*6tsQ?Qw23}9_P%)GyqXG1=hcTwcV^_v70bnk)=OFoF*K=@vu7Q3}+&g7&!944-IQWP`lC0#pc3rZ5qL9tZv$3N(@8mCr>!LF3>=Tf~_Wi>1!)X3W9-l(L+R7sEGdnGUIEt*GFtPSmb)CP!}KfG>%&ca{LW%2-#*G?O7*TjKCGll~Eq?R%3Rg1_8HoimjpSd<8^}G*9Eh^#o9tI<^qQdU`0!Y#lW60E81?(%*+#Ql(|M0_j<j7EUxx!%;BnSs_6bV^k>*$9rl`Z~rNwAtR|Oxv1+^zFUG6p#jy@-#!DAPU2myT6sV_R8h8yTV69q9JCA)akA7h95V@n02$EPmw=yOwLnImgN_aKGDB7S?jt_clVT=#js3|4m^*5cC&1i$NE=^Wj7g*9cKUD@;DRk$*CCpH6%#6;6TU+k!oJP(b?4yV==opThw#6n&VL;q9@@3NUktkEK#bo4O_oC#j{2|rg8Z|yHezhW(OXMBm1}+e0@$R$ORBh_qKSh%8uT+}*1d(PfE4F_w!2fb@7o<aT(5!e(PAB-0RWFodg1go+V6o%mx4Ogu~*6d6kpj~H)3XV8c&-H>Cj<eGyb0J>3{@lr10we(W)fgw-KzZ=RZC_`tuLE#w7}%M7qfkw9gr#MUw(F;sCp)dVg+|_9ajei2{E#8jkGBd53D8f|j`$Pm(~8t-^J7o8+zO{Dv<#t+i*ti#FQOKq<>}B$`2z#y2s+&Wr`DV^N&IP(mvE0JhP={n0^|r$8ER9`;3PA&xPk!L+ja>cCd#@r~_V+Sf@Q6qP{hy5wi6T$MvpiRk0fCceIis>NVQ#0#X%q6PziNm$|vIq|PN1DF&I*6+oONgw1Bl70eELQuRO_s0{>uJifn(>2VrD#dja;FzU6JO{py@$|~>6mypEuD(da%U$$<(`-GdH1ou@p4143_$kYiH7rS%i5E;#3IL7My!7rSfj0D4Wa1U?W*|F1u*MegGM3eKz2=Dm&h;e>{0dhzPbJf*cg4XcmtUl^WYCkiShJN4G65FUBEO^v@orjrKN@VP8xo#S(9;W=CSD9nRPdA<wc@&{<ZPYHs6YNWI3J$&d++TAV3pUCcTp)I7Ps!ZT<NC$AjZbU_44TQhjoNa0<#Z<6o+OyJk!RJgKkeMZlwf5etW0fDioadLC6vGXOrIonfpzUAcb_&sVxx2OMAW{xh>ENqh|%06^Y~r=vvb%kWwqjh)Osml_Fq}v&nu;t(QJrkx98)AIJ`?B<N1<gkN0@PEfJ$_Ikq$P=wC<<FoFh_eMbjwt8AGMiN6E7He%PQ9F!6^CQ|vLjbX0G7RJZFD7q5IQZ3|9<CYF+N?m2O0!7eR&-cdvrwXV<Jur5?LS8(Mjs4p4l1r^G_6qJw`7L0NkloQAp9MG1AO1K4aXo)`@zMak4`_rB*#p-8FTdrg=sevJc)S_q?*f$;%UQ6yJ!k?gz6@m<dOvciPD653ZhGQH!4z^0HQXYc9aI@0)3VvN~89Cvsf&{e0tkT?aS`|uUGizaR0yC`&XY2-T(e#yBX8fGGe}b%sUSz7{5O|9-i6;17SSP$$JKPL?(gZ2p2wBl-ItX^ZwiZi9hK1!RzkC58gfp3?2Q9mW%PE56J3sF&Q>n8gUCBaMl^RX(6^1K8fPk+EsOg!T`vu4(drHX!;{48K%=)ByHgg7<Q6A{1x3cH=uJc8z&MZa)3m!a~Z~@(7t1ip2Aj8pp4W5r4)yz&wz>0&^V_Z2lrumu!ye@vUs2Sn1HIu{m^z3>n8{<rc?|^CEilOR@bUUjiRp_9N_?Fdem0r;P!77GdN{cW!o|pt{FTprjK4U2S4qnBsTIl4V3uwRFdK2KBIc2v%PBP0&x(Tzmm^0PD<^tc}t<tsc=(nAuPnk9l0s?2$Ol+A2aGrH9i!E9I-9<S}gfeNHdSzDst2x<cZn`MAi>&*2Hg-w9?w3ec*pbFpnKE;%^t|(mYXs!-vvnqm|J0$NuQ8U{KtbjVzCB5d|$7fQIXnTd*tw^cA4ghm~h#7@0W|qhMQZtGgbn`))Ww-{anJfIb#w6w<uG$m=nSv3EwaZjcV#9|>B)T(ob=9q*y6IcgtU+^f9szix2L{2IS%W*Ir_ogb40MH0u0EXv4MO1@xdxOsa%wuW60S3uccthuNAG>y<xEe?VGMSxT@bb=6+k<MoVboC4ZZbB(!2&T3!=52Vzr~|`MbnfCcLuffld0kZ{QC#{&6QGqc6VNh&{!k2tuc{poov5Lb?ql7?w*kU~#FaqkdMz&C1q}S6QCoGOBTH4a#bq+vKugpnw%)=&`Y=dl0stb930V2ovM7S0)v}F(p$;e@P18FBmGmNScM)3tr#K(uH^nh9{20c$Qmw5(vnZt@Em?-JS3F~B(@OUiF;qHF6XdyRi_Gh3ut^tQ*v38SkK8F036@bFqCDkkHP86l7B7X)rk-u^y1!q8G$gHVn>5b6%djo%W>@Y_3PdPCiV7cWT?d#Zv&eRVcFuvG-3B>e0T57ESbJnGDtG15ci5J*bpk^meF8^+o6J0W1ysOxT-<peX2M)v0aA?Fua;8`@RnK0yd?;?^G$|$a}%%JDahv6A#PsdcirI3K!UI?FBMxS+6Vz(>sHuC^UtT}Y{eOLNq6vQ$y{L~ljSDtMeF-R7X@(d$3w@_2LKcy3YXdLBVZNq)Fr@9f+-(`Kn3Nc$NnkzNIfuL-`%@qljSbLEk5eY!z))j9$l6CQ5$B}+DL?AvWJ(vXF1Wu!s<~o64&D}izI>V)b>C_52uSHtF(<2*g(}jDFpE;bf%ED=7x)A5Y>1KxT##LWRNEBD&_`c<AFGrl3<t7Po!9L5IPe6n^U_&o!4HI4|wU_hfR`4rFR$+6JEy))QnvcW}=T;8}OFS{PmY#R3k0UhKojG5{<^#<Ixbg@?<zXB^4Jn-glBKGj5SGH0Oad?JT}og|O;TOG6O^DNqmKux+Xm0WxOl&}@M5W{I8+BzUrROM{ED&7!=i%k8&l#bje1EuHS6W3$F<`ymd#oUYqM+=N)sgB~W(0k_YeQ^l_sAM4RGHb;Z^OfzsE<1aJ5I6ohbCLp|l=n;(juLs@9#mHBdEn3}2i)0-!%RY=6Icu~C$aNkcJ)4~>Tt5V`vBQje4k`;KnqcC0oKa+rO}a$+QxLIlJL6i}>`(NH=(*lB5UI@+k!{vvC2Y5@K)~Cu9c>n(<%*Q5cdHm<?EkysK0WcJjZ_r$3Dops^6b%i7hSrS%zHLwuMw?m$MaZieLN*iiMQaArX<v~>UY*I3Io7kOIlTf?9V|CD!}=0F!rnGEWG(k*7Q}0Os;`(XBwTni!>LC<YNXx=_Uo;9|Y_uLcVl)<r1Xvg&N5soufb)0eL{T-B7<Noxpr9Yq*_4NG%&0zmyN5*;qQ%7RW603(uqZ2dy|a!zp{2*n-%cna+(67ToGZi-C|R_fBO5qKO)pSLI@5Wf{sbi&$sNI-Yl5`z4P+Tmq1UVG(E4P)SOnS*ydgSA>$LAqm)V)WDX_;AO{6(W)}sk$;Xp_;S3xi_uuy=1h!<R_$;$Yq7?hy=HO&bM6nin$??|!j3QAqmRz%1#0iX>x=H_1eH_a)`l)Q<n=~DRUqqN&=Wf*C9R~eeqG1tP@Ubm((wY1sa+nf02&x`o!gU<U}MnRq7`a&q-|QsYVpvvCaSte@j+I$xn9OhU_%|2Tfwq+O$1aaF1C$zgf3+l<7KX9of3Lx*{-Us9{ork-AdnY;4fc`GOgh<pHzv<M8)QD#@xViF_6Au_Fi@70{V(SVLU5bo#6|&T9giepcGlavpeJPioFA9^0$lOM08$fv63q<jnil+*8OElb+~~`@s$^?6iyW8!O4@H@t}J?egl#hN?)J`^k4Ns{3=G8d|biW=$=Q?sG&GtGcO@ljyAe5cc^m~rHs7rPu597GrR$D1)aT;{5C3lk)CACjRfH`O8~>-JflIS*=@XTmnj9pZp~RV^Zs_wD~N~RQ~~A~yrem-{9h*iXwW?^j=y@tu?{eDKkS~I*d}1(R0}Z32rY?j94g#_Sd~e#+)#=;YH5I#jSA}@^JS`d<5!lyG81L#{{)*Dt?1;ahuDrsAe+ouM6;WScd>?t>^4j(=n=^jE-x>DuHS8Sl-R~gk5xR7WA1E+8L|R^gv7h53$yCRob%8va%ScsUzWZyHur5NZ18?69G7$J#2@!8qV(2tTlZ2D26@G2iU&6#-*!~UO&_KUQ2VS~pnl;3Re1Cs!1M(X^I-($gR!W5d~KyF(d=B*wN}wbi?lV`8xK)lv=guLL`+Zt^lBD;0%#o}$V)7Qg;pJExI^AE0AM<_qsm)wW-{^zCv`}(M!hlFkShx`dPxmlRXzu7iHeg^{vHp*;X@g}^@T1qf@rRr!4#KFioV7_EeyFXx<R2DK0p6qXG+;PZ5$(__cP=N4q*3l;1K#a&CS2@Pt|jEc)(L#=;#%w!tkv0QP~=0R$Ga@F70!mQEU=AM`Si+b}ZJ}D;qq}K|fh6&~A2(hfdsd5ZoVe!CaiFVyEad!hU)!^>_h&jZqCHQ?r$U)UpisuR)YXoTO%>48zzh7O#$SaK^~kifxqXgEUKXM>f=H$wI<ICo;)%R9%)0)@8A1@GoY10A(%X0aon)1+%**8z~-QQ-LzSmfafHvaT<cE}X>h6`iAz28aY31PI*LInW6!0p^uun<Y}xkO9X+Pn=?hFSv}S=?=_(F3ka0hRgw3OH==VsDwF4PP`2e<_f*MEYlVJ@TWQ*-l|vPOCpQxcDoKqG85C*&-_XEq&w*bT&7YadYU3?Ia*WrmY6&}#49-grXDBk`2O;$qK7C$#Zr8nx|)by=<toJGoY<8(ZXO}ll8931eb<D=gCKp1_F|xi$VWy7rw1fNw%plpa`43JiMau>0B>ftvC6Y3c~cYg6vzsT2bKJw3w{$BiC}=d*h#V(W3@QooeVy6ObnIm^LSCnvJaZU^k7XDE7z^osWj+{%F$o$A(cck`hSh7QLv#W%J0iHXaKuI*lJ!!KM(Eak7j!#4_t+8m@t>E?A6Bn5N+axrl&3Je(f@?-<StN^&2jafq>Auz|EuUR8@c^K@WvZvbqzw3oJ2p)r)I@Nt&+F$UN%+ZR5-EJV`{`xcAV?b}vG$j8#E(TsL7jmEB&#c}BUs5QCbR;h*k@)mIhSnZNk(G4?BJ+)xac^tXujz-=00&Tiy$NkqA!;7(sILq);yxia!C~IGm0{GC!$VMHhMRB9@#zX^TQ+WCruh6{aGSO1-Os8ZdCkG4OD0x(%Hw6Mqbo8<^+e$CIDD%YH-GHrt=@@<Lm}N)dE}GFWna?v4ySe4CGBH;fm}3|**}!?>OV(P4H~LJes-r{YaMx@y<ZPcThn3<)^bMyz)@Mn#I&1)6Ds`)f%(bw>l*bJFnO!YfrGd;;%dCvXah9!bv@UF+M*jHXbTT%rkA$-jJaxIv5J7|kF^|AFXd}7ab=<>u28l)ek12MfDlw4Ki<-iu=VN)}4r~m%Z=NQ#`YjV3zv-U)Tc#?PhkDa3Gj-$Sb@+KA+e_&3$X??svFu+pY;;~kzosoCmz{7Hc_k*Hqu~yQPZb@NN#MN96A&td(sQeJriDS&Y+)7F)Y=BfI8fSoUDQPTr~XOD24Y1toAuES$R8vKjLlU$kvO^cXh;}Ip}KwK3Tc+dZ`(sgmZ6E>MqG(!s{0=FbZNu8Kw33Sl{DisuLSR!D^;u_6~M4P1_~dutIurdw<xo@nf^oHL1l}g4=ne5#f%I0k=<0YY8*GC$IfsUR&-`TuLVWLR9-fl7w+l|z!U+)B0*~FsbN3%eFVrG;98<JiE>5K8(b)Q<9y>xnY(+_JQ@2|X@NMqFqc=%8A>I^B37yO2paZBktenhhoj(4e~jMKUrC-+^{F3_6;6;m^cH=4)Uhx*aLH7KhFllzRM{em){4=U*}kSAzQz~^krj5SJp&WesUBLcG}~FlDk0#kk~dORRGcxZ?B#)#&s;_c<@W$tGGdusKHf$vvQBZ87pmg^nS;OyGA5=20ku*Fg_m5?!W0c>Ele7vpqXPGU^ud4{U0tk>q9CZDCZ$F?3K%1Qv01N3XU#)>d?1xDjG^DA|!Cu?q%mu0yk?z6T5j*;5PmUU?t5MzngHrlYp+w<BJ)aix}G<++75DYLJWb#SFhfsFw{rMzm);tWLBy5B3rAy&Tg&QOeh*@c*)uuTJz|Bju~RRwI)oMEI&H>?rY<x~j<iU&%6eM&-(+e<uw=<rjZtaQSxOz8J78Ft@T;B2(5QWc&X}(*Kd9{})Tr>fUUxleG-yqaeorje@sEM;R`Cwa_h?Tvkb3NOIHcx*e}@udOnc<!@^WLuRyKxj%!+s5=;Udvx&KJw+SF`(SwPmy;P9Ne}tK@j-OzCA-20W!bo4v;?lg7p0W5wYKtQ?U!mQrFv%UZY^iP?(LNjt4b~pPIE1%@vF*4irt75gJFtbA+?RvjM>>`5gQip#6R^XzV1xKyod4^KQ$~~OZPna{>Q^Z*V$!=j}a&uHi1Z#g5lYW$=iD9V7<^`+M12LnyV7K165Brse@HIW!1As+w8CP<6+Z!RGqi9HBcP6E<2d9w~j#;{!&`{;zpkN1M)}a4|T<SkM{Xb=*Z-ZWZE6E;=Jxc&yQx4%rQmb8RSY-NAVxg4$Jg>nM&`iB2_WY^6Ec^rd_>+sxh~-Yo2o7#f%A4mU}BJN8v&##p2+Khz0(@D^c!tQ){y8b(C^{an?De(^I;t5P+%J^`fPgvnAMI%A-d(?Rtwz1u3vcNu@U&Oh&^~Q`E?o>ud}(Q8dPKE~t)g+U+*VV37n&S%?LR`6%Ku0hWocm_^3LAl8Iw12%(Fvq#4{CiWdupa4(k8`#gVUVF0!po`oph2LF@IZ~$af<?KxEQU|%L$P>J+Kw{qHRtrT%fpm;6G=H?i4*m_!yU7oVac5K&|@QEr{p*kHcZl}s9AYg1T>9D`w90onqhQOxdi#VQ(}~+x@k1WcO)5n=9wes7%+^F%54<()tCLxNZ`IWl>itd;d}xnrwS8b;+4EOjYfmR<V|$yEivqF0I@^uivi&D@Dy`^u*?dBAz8qVIc{JOHNVEnQ>Ml_A{!4+W!`YWripfxAd-f8d02r%QgV?0&a<>ma6v>FOsuJtV0kvVo~kVCRw0E=TpD6ZnUy4Z$BTs<-ru--iuwd&s+OAtC5H`!2RUY@7X`Ri5=&Xn^?pJu`_L{*Rnyli1VGJ7Dih)(f5sn5<}NCrj6um`uQkDXBIKqPURo?+8BC9Sm$$>LNTmVftcP5vocx}f-^t9FNUW_WS5$%<+O%BbtLP&TwGW$UgIT-n&5F_m;`Jl&OMNb1i-xaQPFD49w5>BLrCdkiY#XA@Rf5KE>=4<>@#YSikM~n?Ck;HaVZj5(0el530P-XgFY)d~klR~S*9BN1slZ@#S{#R-U}e|?)^yxrD=I!rVtm?t83p|&HqV(TJFqEWGOKstF&zddX8}U~QSKs82yuGJEz64hH7i;55e+Y|N`g_!!#@!#)z_M}S}9X>q!SR&<Kx?_A-3OnN1aEUtbZ_5FVqfoOP_8Ubc@$U;~(GW9}H$aG}&q9y6-$;tTP+sb_#<no1&B)V2U;E@=n;%RB@whEvp#IngtKDEsV>e9FS7{6Ip8%v~_tIrI!`m0%S6NRrc%-)(@eVL94E?DLlgt51u<tL(^OIasckfeWrA8*|QA_>~4B$y)r6w&IavL)hNI7l<ROzYU931X{;)Tm@T9}tg0MGxs&pyM}&x+ZsN*7C3QqggSIKf8?OWpAVic?lZi|h6%DV6U>4~ytj`K*bhLzJlK7QK=d9v&91;XVB|TZi-#DzvNa=Z2eYAMJgD)S+4j#V#FWufmCPXt*%_3(TZ&sz9mBS8Rn$PD3Lv*GAPu<aQ&Vc|@Yi>K;D3_l_RElm1k-e~+BAcqAf*P)1kRX8U(1i0ySc-I-zUE~52(R1Pd@5S0&lT~gl5?N|jj9GL#aX~?!2RMHyhAwAyDZ1^tGcDZFQBxEst)+Yc{&po#Hn{R4!3?oNCR8*ZkUX^C*9-zDQXhtu$YR;Lc6(C&@m(ZQsIONi>jXeDrPd2K&3;h7Y_^AtJ<C!{oAXaN^ufdtpb$N!#{3K$iVh%S!*n8yQP`aIRKAPRiy+Pn;gHI#FHgQEZeJ8Llat0)b*#^EzP%T881lRt1<2uyoVB^XDvrs5K6j+Qw{VhUBO$?VlO6mPZVfmuP;u!qu^bCa58+SimsI~Z#|i#JOyJfUwABOqo{?s8~O9DDI6Q*Ph%QKMG#f4NE0G_Aq0pkH#k(c$(t0f#CtsVDPO0(>+;s5iZw6r?g?bI`ZAj=WhE@IQfA5siWFztuSZsR!p?G$ax|w(MU??40+NoT>qWQ<=!lG-m@1@<gzKIqH)xUGX7BgmI|5@m#$(2(Pc_()T`-u((PEahjMPm9MRk5A@aQ|Z=>E%IBdO2OSf7b>bd^>eJybpV*r2N$Q>5vcdqgG*R+L+nzoU#>pzf)99tWq(OlvL=Dq|^`lo<I)x{z_ZlLO7wq*5sRLA~w!?;0&{I9f_v#KO~Pmr}a@>IH+QG4ag&%;u)%J!g%opRcwXz4&-pXx90t-}7sRT!{l!hQtt$<$#tZ3{3vP3SH_2N>?S8thYQN5a`pRi8PN3<1F6<yj_p~>+Fz^jL(yr)hDLSWV!*}e2EDbg^inIbXoY_X%6S-0ZT{SJuOn<mgXXbj$LM9Zc!)voU+KM-kUUBf{FtAhD_HjF9;|rAI+yLqv7jO_Y82O-wXU-{N9DknXgIoB`)N71|GCPf8xC2?Te>9w{$g4=@uAy)>g44^Oj&6uqs<Ip64s-z3C1x$NI^|h$Xv5{IH$>&jct2J)XSMtCC=r8_t;Ll0O)^baAexb>OH8kD^%+&ob|Gsvkm0iKxy@R9ua&pSkh-VwJYOlo>=~Hl(TtUqZt!o9|2KYT~<`M{zo*&v=V!%yS+wK@N7d-^E<r-B%MyvT8RJ4M~k}0B|j$n{X;499qr2pZc%6un|~Fwc)$LSWil?+km$UKJ*r-<ur=#qnSsB%Vh#!N>=eyk>$QkT-cR&GMWxcLm#b19=W&GO|_-%b#|--P<dJE#xcdR7j@|lVX91q?Z(R688_qDgJEzw9N<08>{1B2s+04&8vam6k`<9&<_*$rvs2uEtGe^9@NHg1<`h!tpt3|l6nk13^wZYSGd`9=#>QM&!S!Z7kHpPC2N=p;TpX$<`QHk8c9bIS4b>CxYxJEPvi}&1w_@hu?MuVAa;UJ+zg-Gr_si!$Yy|*I^)DQD*x5%7$zmct-v91h7Pp!U%ut9u8^)EPA`Z<{&MPX%tz=o}m&||X@oPabqu@TK7(8g<<1>1E?!45r`yX~VNf&o*y+%4MgodWsid=U)aZ@#!bn#r9srx=k<2mqPk&v%QXy{Y~5X_9p@?mlvyFOKBSt>D@#%i2gkwNT6Ad1wB)yDPoX&wpKTPT1&!%mG)NRwBp*+bFBM3Up)$oB^*7E<QX6O`H;0&%=17hs~dL~hOB*SBE?1<pr)pt`8kM9ko1J$>#w#iD6At=BK*d5Gr~TU5vFU2^RAx@W$@{KN%3H}I5nmZGt}#<(P?KpYau7CbvIJ#p<z=_a)u#C-J@wdNhm^Spaar(a4o_($a~*893%d$OTR#0qrjSSKH~gDdhg3bR|UbniFjViCzx*X7#sJRU!7R*Q%^X3T<`V#+YEFZ8-_YRnHRcYIlUm%P|k{8k|44(uk!!R~pthjx-3C@Yh2Lty14SyTVnkf26h_PiZ4Z#@}(TbJzs^Sp`pL1a0%Jhy0_rO4!_^={ywNRzPu!oMR&;SM6+WvbY$MNv|{wmGSo9aR*|Tj7IpX;Ze-ERfgOV+e470yH{#y?7*i$8SKZ8k3;{1TXHFYVt`Vh|tXwoI7&DeoOutY?HH$q5+dSO5PjQW0+dS4@eT1DbU^Qtv{+P`(x34ySc^tos2EtaiZMWVp=)&UkyhX#xyBzDE+rSp7=w~8NOK|F00!6b(r(=hfZydu3&gtzhG%J=Xcv~Hu0>DfBxKRavM7KU-t)A|Ln{^>FZ91m6PJ%;c)En2V`5_sJK-LSl<qZuguAD3R?;DlxeP4^uH%0*wKC1Pnb7Wxmg6QJh`M_D$jM*EDu!ys&3O0?}%5x=e*B%9WF=d$03zVb=}G}x^DI2T<6Q)wn#4l%;CraDhEi#z`Ddct^rLWap$F=m<rGoZ#BBE1M{F}EjAIyF|T38)olCiM51b%u=}WLuO$+vdY8f}{)+NB%o|a<fxbP4#(gWDYoK-8ZQQ#}Wj9;*SJ}I(x{NV4?%N3HH~Dq!?Au`wHp<3(X_?uPly4=0WS1#)%Bt~SY!X(Z^OcU_PqavuCn{z1o*X_YIfNtS+jSFH_hDuIA9JBbDa=Z-dseP{(zHLrZCr+%V^~gYc@I-@E?Sno*XvR#anxux<w=G@ifcIh((4B1sE|jjB4?8Fc=3s=v|aJ*hi|1gAPlN0Ei5G<Rpvn8P-a2Dl{1ynJM%G(@|}WZJUTr6rm1&(7$$M*pS(u=Rl*!flcv6TD1&LXrfAMeL<WlcuLpQks_sog6yDaYQ95+yK^|(GlZ(*+ZC6UXlN3CJ(F)@+0@4CwVR~z3qlRd}QUK^<u9^8K(i+P|Y_>wx09k&~%^MPt%^nGb>!1ef8cW>X*OFQu(DTG4u2Mlz7BE``%Nnrs5yV#95XD6u<z7X)c7qJX+}KmS8J*v>#Z!mL`wIBKMo0ABe9u3Badz`KC$C$BlX-(<x#!gz@|vP;u>Zn(v4fMhse&;Srd+7r8{1TRH$U!g@!r<BUuI;Y-|RwA_8ln9PP=ut%_1hPf}p_R<)<_K9wuoX)RP(F;p#+Qcs=mnjf3vV+x~b+c@34a$Dr}-NAo#eJ}D%9YrVOKjl%`^720ZnyIImfhwc$;*NZ(&vSia+MIW<(+RJX0>$CYAq}E7{MFA{bIVw^=w&YDC(g1oFJ!Go7Uw<PCoACgeQD<l^H(AaMY#R_6@ZKqTgPK?nz}*$B9A1^#u3mYz_m!5*YhYZ9colhM!xi)#FVag_Ah(FmL{%Og^v$IbI>Id!+xp;d5$?;6Is|xk;D>4yR?$=GycmURwV$0rvKnq~DH+4+uBXwtOZAo*>mQVQQ_R+J%2(KEUk&!LKUu?%s;wEX;p?E+p2Q(hn_s+VC7Ya-*8CR89KX&=TiwjPRad~AHw{%^u~s}+i#ht+sFWJbT1^(M`tWwZ@PD1B)K-tFZ*!K?U8RgZQak!e^(OtdzA=*}osm{e`R=VN5|Ulf&DezU>~u$3?u{7=YL1vq78K^>V@`Tfk}By8pw|Vh3#Gk6pmg~R#ObW5DfMPz9wy?lu3d2o<thh<rpfJ)<fCrT6&Y9znT#L$MYx8uWF}UA=GfD*bt7%XX^-wzk#vc+uey1gecadqkUR@!=58fF3FVnl%#5F5lNV`lu8QtBWs|)!@}P|Di%Vq!WR~oLrd`}ME3hy-Y<^K>+w_iI$hBFvT4J%Es+iqG;v5Anl<}?Z<vm}#S$6*+HKjLnkGW)OTVgVaa^oC7y+<i{in3=g4cBoVVs4FRLf(4DCbchyp@alJu&Xd4GK{SNXuksI>#ycX%kC~g0GNgcAZ-Nifye{nZDY}v(~h$Q2ENo{NM^83*qSB@(92+vWTjhJSmBxrG+)JOhV(4P6b<ojOvK@KN4!gLPFbvhmoCDbi#4;t$)IwFrj!H9xO)OP%2Mi~UFNt8RJ}j&O>TX1e%@!8(u3WBKdvpMn-1+uS{cU`O96wnI}OX@+H4$lhm?db`n59D+a+~&g}&GDPzKX6?;ce~0v6CvYfi8e<_7EV$Ijv5{_{il%d|=hw3J(G@E#j%|1t9mXMYEAb;&La-vN#Hc^M88rTeQA_FWc3zT)R;dfno)^Q;&~r4_XcOZdGT2Uo7ir+h`bN`F(F!&e8x<L2r|yU(G2P+Q_D`sKZ>0JPYE0e2cD_sl}q+n9H&OV2w9xCO3?nbz#H)8Tj=AY-eBz33qo0Y5FD!*0K|T_W`&YelK#W)<UYu8~%@kzaux8KB1@UXvzLSTRF>Z#a0>e|<4xmt+q|7=`=RA897TiZnu3NdGg~kR)eYlB|5Y*VOfzP<)%u6c=XE>xla;{~?Z3u=Bzx<ACU4Cw`Wkqs#<JeB*C|O&$yO!nTF0Oj7qBz`o}30@PZTXyHmzcbLl-H^q@K!&I-1$*Hm^sOvs|tcRsGvTt&<?7i=u`py28+C>nx`3v<SSxSZ-<=R(cw!&RJHq96L{O*3eTi`0>O0C${H#zqr4J`Zi{#!fu{!3Bs@vgnih$4tWJ6xkC*3u@U03O)%O^jDr;uV#J)>EM^LhE68!9tK!J=!Dxd%6U&P)Uxi_Er4^UGmkB&-9PaLEI>N>0har`$jo(xD^_IrWU)2lrl<M(?u9B@n+vO3^gVrI$9h-*i2Fk@z-rYidH9PU*gTR-Ubzahr+eNsAO+<BGA=rj;KHP&(F~%b};D&y*C%5fjrFi=pyJs=VlHEyCo}B?OM`uCVZ}?ep~N&-O%c8VQ8j+S(vU6cWT4Zq`6_oiK5#?L-5U6_m`IR*-{N;Rl8~?BW*w(Y&nJ;kJK04S**m?;L8_39v;?%?CVWz6&qS@A3_FsQ3;E}O|;xB*?CN`$uI+B2PCN|yep|*O__OWlkq%8;B(dNdu6A2kwQmtJ+94|V|GP0dLi><U`I8eOFf>Frli-N(WNQSZJx&LGA9(|Zh*uHN`z2=O|)M~;uhWh4mvMW+e$Y&31IMc9=!57UR~CkEm?re?V@9$R8`6!>x|pb(agKd**)Ksu1r5W#RAH@)BVxKQsmXbxFF@ubr@&yZzy;_CPPRqx&D)No+j53a}+{H{f|K6fGwbZ`CkDD`6gTx31Nt^1EIc-7Rkr<Zk}e1S&ayh+zPPW(i~k&aJ-{!E^ym@)jGS8#}8ghkcI<|A3r9966j)6;v6@{E8SqC-e`C+I0-<B98`ljUwCySQuXiHHSol!B=HF=?frpsHX`bW3ZA2BRA%38eJJCM^RGnD5C1BxM0|LvuFS4%%h;Mh%rKp}2q2R%^}*5HiptK|CDs(pJ>y{vDFYu&Il4?4BMZw534Y97obp!}=|02(iEB$2BfEnhPPXR4CGD9;cLi+zq~Co#7>+0X-dOcin8o4EDnX$-tC|p$JOf7C0bU&MnKJG*<}YF;P=9~|HToQYU%v^V{)RI}5#hHtayJ)>(4x?C<6R5}h1?ctUpTc9gS3GF*rrJo9>zDckX9*5y7$KK{VZ+wL3h#|?OARR6+%oh8Q__AK&Eo&17}l8LAci(Us-3&!39JIcT_3JJZx8v%Ium-vnUVag|uil-_cYoj%G1Ir^wNXf3np9-0Wm2F0v6<$4OkNS|ipN@I>BbP<$V2;-xwiBaYX^v!BnMnz^#-j2ZCx@)n<3$Qo*@feJ+wi{p~s2(XSH>^;-Lv%Yj?UA*Sv#mYkBmOmf)ullDLSt)HE4YidOZMt11iY&7|g^^vN8__2avAC*g?|5?%9Wa?UbNy9~)p^VO1U-ytYD8qEM|t-NX2k^6ZO6`dmH_Gs5gN%vO*af*URv8T5j1vnPPc|*<kq|XiE&QZ&Y(K&5^7Mxj8Nem&b#CB?}8`@SY|3>b4QmhJRrT^<jhBh9sSK>cHu+AjYLERmEgLz)kBFLn18aEVaU1gH{fcq+tipM8M#tRb}cSmpa{f9Ep4j|ud}wj?Gl<2I~B$^1X}f~no_DjE(ieF<h~jVF+}*Z|Ee#pv?y^5TRm$)UJG<d{B(>71vB7iX%wwcUSK&wxVu)VG!IZ(-NY;6K>%Bj>Tq~u=mrEq90`sAZ_v02OzrHfJ9=*#pTg0uNhC~-9L!!Nxmg^r2MLd|_!wq9Jt{gaTt6sS)HbZRJ;95XH_K(1K3KCPVnV?*O7nRBV9^vUIX7biU8X1U%<a~FxIhCcJNHMIvkY1RayLaAU#{TiUrmjHq)HJd#Yu}QddVOMj%`FnCI7Vd8Uz=+@V8c41XwD+)C`U?BYi2TxiK$28b!Q+mlW=*wT-MbwP|cjso8f)Ohd`p_jb%kqvd+%8EGVtOGZ(O#w*6S4)a^@9R9TQGh|-tW)r3}x<4Av)IkS0xDV5VMSOjb#r*JnA8>QMPX!O?Z#(+{v@QDHu6iP2Z*34H=jdNu8~~#$W>J=1(#YDttEX1cG;dMOFbg(m+;X1TKP{6P-lAi>@PeJ~$V;*vw0D>9cN9bqT~)cOl1PHR#lx04(um;GA{wFM2h0N#gfnnw?~&;r#7!%FrBJU?+&JrfI29KXA{U-=@31mYIkHl~oqqF>(YVgq?bN0^F(#@n1_TPVS97b*w|h)K+NV}DwPO+oImvhZ$(!NDL^?!O&7jO>u(XWM?gj`3Ehc-aUT)tB=!u~NK%Hm82XDuDU=$HB^|8#7ARJpy-*@b1nPWJlf^o1RIsd?C(R%}IwR0VOw<}1LnUUqA4iv^=nj(J4!!69hJZB~x*RB+?9j2RKmOv=R(uPUHMh}5!qGjdKu5k}CAgKgZv!f7_5zSYaI3Q2^k>Wi}?pnP)<Nn5jRliBm6Y1(eAi$m>=>GSPw}*YZjrleO2$T-8_VgG99sGP2<Q%(5!db?M2D4(7)B1&Yag|F$_JFD`SXp|Dt~13eDx%h|>M2yqV{PddO|UQY7r8&I&Pxv#Lowd6L0?t@&26^@+EVlMS2WewQn4E4mKyU&D2t(|g>bClz(Sv{(|&IvRos)I#e@Ga=#Nd8)Q=e+;VUqfFBv>>Wvj^&+;|0)18cEID(mcYQx7{^)}$rC5rEPQ4shZ1xW;SHk~MSTQ^3;^ZP?^k2denFt-Fvi*z<IlFTBS=zi9q^G<?;c1g}nq!%?Y+?f4;goyZ7Do(r_&)yz)x;>BOoZr}OcpP3h)v?~N7B;s~8eiCc!?J2iTZdNVKuEWqCk7%W|hZpWeE6jLQo0++i2lTBUob<;yf|H;>&>aOityKH?>XgvmkPbRclAKAmWWgsL7j%>qBudby1UbM`?d2W32Qd>B66Q$nQlL+e+_7IIaULdr5qprt)E3q~uz9c#4$*en3Glm?9oi&_;ydMH&*>^(;O3d$weXM2UZ4vC%;g`-ufeh6e|zl-IaupY3fjfaT1QilMdE>w-bPoxHoglma*xFBK=|;AOa+06X9~nMueQsNq1ev=X1;-nD1xgLRD3V@$BR>s*mn#6=tCsJ4ii8$;LW$><+qg%+9$`#BFbS&t;8^<wsez^0tPIA+=4kv@fQlzaC6KT;Y~GjG22SA)o{IDJOn}jS5%f;fUF^tIq`v}ti-j)a$CD>tWA7$=d@duj9aRhgAxuU0=Y?&8TUc9K`b#=XbNtpS>Xcej?7nH<@TxVv7U|XRqvT9K!TLWIHTIrowc<8R(z(10lR>Oryn~VcFji#wM!&I5$hI8_;J^-5CcHT-}{?DD#mnq^_ULLFlVfX2<2Jt{Fn~Ni31^FWas7PLGa8$@7T`OueGL)>eM(hqJgUfPW*vs{92r7vMd5?nL9ul4vzlo(5cDN(%!5o#D~y^8USL6wkF)%u*sL}mg9oDfMhfaFu^uj;k@;wEuQTwm!HBQNdnf7AN4n7*>=ZBIX-FSC|88Z30pghQ*l63L4Q5w4AUv+Z1}QQKkZ7Nw-L~_>nO~FFqiW;BmtXw37w_Dlc@mW5W)%L34n(i()^N(F^UQ>?ic}%fhk6BUd0)|5H9rmBCZK`Fq7#mJL@D4Z_8-<;o$VW-B4#+<3j6=vuuOrKC^2uMevXM<Da=z`wUay)wmJ+-O+$__#Ml$Gkg%wSdw-OtLS6qT%uQXm0&TL#UJ#E$>;*x4|=E28NBT=;jX5plmJmE#Ur|r4=sS6f$|w9_j^5RtUvb8yQ41UIL8oG%ud;T?FT*3YPR-0o^;WuF&=c!$8YcuiP7X^bcN}T*!^+-;MH){Gx}X$HKlzH^JED!D=Io%{=%)c$=dh^v)tfbG3CfXPQ#tApFTAe(<xQ9h@y21V@QtNqr?4HH7gerCs38zLzxAS0EEZ_l4}MeGfZ#jsohO)Hn>^N={@JitWZ0g&4Q4BZ`u3%bOrPc&V)H1usG5^k%7+R)#x9rnDOR-9IJXd$!Pew%^Gytbl{vvpK_7L0m#8-8D@8_!{qQUe^D+Uh3TVuB2*NZAo}BT+T?k55a48kfM<eZGvC`&eN5On;<*n?3@H2d`QhIG0ILg_fB'

def fail(message):
    raise RuntimeError(message)

def prop(key):
    return subprocess.check_output(
        ["systemctl", "show", UNIT, "--property="+key, "--value"],
        text=True, timeout=15).strip()

def read_db(path):
    return sqlite3.connect(Path(path).resolve().as_uri()+"?mode=ro", uri=True, timeout=10)

def main():
    if os.geteuid() != 0:
        fail("Run this installer with sudo Python 3.")
    if SOURCE.is_symlink() or not SOURCE.is_file():
        fail("Source is not the expected regular file.")
    old = SOURCE.read_bytes()
    digest = hashlib.sha256(old).hexdigest()
    if digest == AFTER:
        print("Already installed. No files changed and no restart performed.")
        return
    if digest != BEFORE:
        fail("Source hash differs from the reviewed diagnostic version; nothing changed.")
    new = zlib.decompress(base64.b85decode(PAYLOAD))
    if hashlib.sha256(new).hexdigest() != AFTER:
        fail("Embedded payload integrity check failed.")
    compile(new, str(SOURCE), "exec")
    terminal = None
    for node in ast.parse(old.decode()).body:
        if isinstance(node, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id == "TERMINAL" for t in node.targets):
            terminal = set(ast.literal_eval(node.value))
    if not terminal or not all(isinstance(v,str) for v in terminal):
        fail("Cannot verify terminal intent states.")
    if prop("ActiveState") != "active":
        fail("Worker must be active before this guarded installation.")
    pid = int(prop("MainPID"))
    if pid <= 0:
        fail("No running worker PID.")
    proc = Path("/proc") / str(pid)
    args = [v.decode() for v in (proc/"cmdline").read_bytes().split(b"\0") if v]
    config_name = None
    for i,v in enumerate(args):
        if v == "--config" and i+1 < len(args):
            config_name = args[i+1]; break
        if v.startswith("--config="):
            config_name = v.split("=",1)[1]; break
    if not config_name:
        fail("Cannot identify running worker config.")
    config = Path(config_name)
    cwd = (proc/"cwd").resolve()
    if not config.is_absolute():
        config = cwd/config
    cfg = json.loads(config.read_text())
    def resolve(value):
        p = Path(value)
        return p if p.is_absolute() else cwd/p
    root = resolve(cfg["state_directory"])
    control_db = resolve(cfg["controls_database"])
    def precheck():
        with read_db(control_db) as db:
            row = db.execute("SELECT controls FROM equity_control_state WHERE id=1").fetchone()
            if not row:
                fail("Controls row missing.")
            flags = json.loads(row[0])
            if set(flags) != {"bot","auto_trade","buy","sell"} or any(type(v) is not bool for v in flags.values()):
                fail("Unexpected worker controls.")
            if db.execute("SELECT COUNT(*) FROM equity_commands WHERE state='QUEUED'").fetchone()[0]:
                fail("Queued controls exist. No patch installed.")
        with read_db(root/"worker.sqlite3") as db:
            states = [s for s, in db.execute("SELECT DISTINCT state FROM intents")
                      if s not in terminal | {"LOCAL_BLOCKED"}]
            if states:
                fail("Unresolved local intents exist. No patch installed.")
        return flags
    flags = precheck()
    print("Verified source and compiled payload. No application imports or simulated trades.")
    print("One extra quote batch only for stale managed holdings; five-second request timeout.")
    print("No sleeps, order calls, changed freshness limits, or changed strategy settings.")
    print("Permissions:", json.dumps(flags,sort_keys=True))
    print("Installation briefly STOPS monitoring, rechecks intents, installs, then starts the worker.")
    print("Enabled LIVE trading can resume after startup. Broker-side open orders are not certified.")
    with open("/dev/tty","w") as tty:
        tty.write("Install and stop/start Equity only? Type yes: "); tty.flush()
    with open("/dev/tty") as tty:
        approved = tty.readline().strip().casefold() == "yes"
    if not approved:
        print("Cancelled. Nothing changed."); return
    if int(prop("MainPID")) != pid or precheck() != flags or SOURCE.read_bytes() != old:
        fail("Worker, controls or source changed during confirmation.")
    metadata = SOURCE.stat()
    backup = Path("/var/backups/si-equity-quote-retry")/datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    backup.mkdir(parents=True,mode=0o700)
    os.chmod(backup,0o700)
    with (backup/"equity_worker.py.original").open("xb") as stream:
        os.fchmod(stream.fileno(),0o600); stream.write(old); stream.flush(); os.fsync(stream.fileno())
    print("Backup:", backup, flush=True)
    stopped = False
    installed = False
    try:
        subprocess.run(["systemctl","stop",UNIT],check=True,timeout=90)
        stopped = True
        if int(prop("MainPID")) != 0:
            fail("Worker did not stop cleanly.")
        if precheck() != flags or SOURCE.is_symlink() or SOURCE.read_bytes() != old:
            fail("Stopped-state safety check failed; original code retained.")
        fd, temporary = tempfile.mkstemp(prefix=".held-quote-retry-",dir=SOURCE.parent)
        try:
            with os.fdopen(fd,"wb") as stream:
                os.fchown(stream.fileno(),metadata.st_uid,metadata.st_gid)
                os.fchmod(stream.fileno(),metadata.st_mode & 0o777)
                stream.write(new); stream.flush(); os.fsync(stream.fileno())
            os.replace(temporary,SOURCE)
            installed = True
            directory = os.open(str(SOURCE.parent),os.O_RDONLY|os.O_DIRECTORY)
            try: os.fsync(directory)
            finally: os.close(directory)
        finally:
            if os.path.exists(temporary): os.unlink(temporary)
    finally:
        if stopped:
            subprocess.run(["systemctl","start",UNIT],check=True,timeout=90)
    if installed:
        print("INSTALLED SHA256:",hashlib.sha256(SOURCE.read_bytes()).hexdigest())
        print("SERVICE:",prop("ActiveState"),"PID:",prop("MainPID"))
        print("Startup is not proof of quote recovery or certified exit coverage.")
        print("No strategy, permissions, universe, reservations or positions were edited.")

if __name__ == "__main__":
    try: main()
    except Exception as error:
        print("STOP:",type(error).__name__,str(error))
        raise SystemExit(1)
