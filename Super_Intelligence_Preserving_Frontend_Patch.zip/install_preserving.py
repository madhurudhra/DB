#!/usr/bin/env python3
"""Feature-preserving frontend shell repair. Never executes the bot or server modules."""
import argparse,ast,hashlib,json,os,stat,tempfile
from pathlib import Path
from urllib.request import Request,build_opener,ProxyHandler,HTTPRedirectHandler
ROOT=Path('/opt/super-intelligence-dashboard')
BACKUPS=Path('/root/si-preserve-backups')
HERE=Path(__file__).resolve().parent
TARGETS=('index.html','styles.css','app.js')
class NoRedirect(HTTPRedirectHandler):
 def redirect_request(self,*a,**k):return None
def digest(data):return hashlib.sha256(data).hexdigest()
def served(name):
 path='/' if name=='index.html' else '/'+name
 with build_opener(ProxyHandler({}),NoRedirect()).open(Request('http://127.0.0.1:8088'+path,method='GET'),timeout=15) as r:
  data=r.read(2000001)
  if r.status!=200 or len(data)>2000000:raise RuntimeError('Unexpected static response')
  return data
def atomic(name,data,meta):
 fd,tmp=tempfile.mkstemp(prefix='.si-preserve-',dir=ROOT)
 try:
  with os.fdopen(fd,'wb') as f:
   os.fchmod(f.fileno(),meta['mode']);os.fchown(f.fileno(),meta['uid'],meta['gid']);f.write(data);f.flush();os.fsync(f.fileno())
  os.replace(tmp,ROOT/name)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
def restore(folder,guard=None):
 folder=folder.resolve()
 if folder.parent!=BACKUPS.resolve():raise RuntimeError('Invalid backup directory')
 m=json.loads((folder/'manifest.json').read_text())
 if set(m)!=set(TARGETS):raise RuntimeError('Invalid backup manifest')
 for name in TARGETS:
  if (folder/name).is_symlink() or (ROOT/name).is_symlink() or digest((folder/name).read_bytes())!=m[name]['sha']:raise RuntimeError('Unsafe or corrupt backup/target')
  if guard and digest((ROOT/name).read_bytes()) not in (guard[name],m[name]['sha']):raise RuntimeError('Concurrent edit detected; manual review required')
 for name in ('styles.css','app.js','index.html'):atomic(name,(folder/name).read_bytes(),m[name])
 print('Previous frontend restored. No service/bot/state changes.')
def main():
 p=argparse.ArgumentParser();g=p.add_mutually_exclusive_group();g.add_argument('--check',action='store_true');g.add_argument('--apply',action='store_true');g.add_argument('--rollback',type=Path);a=p.parse_args()
 if os.geteuid()!=0 or ROOT.is_symlink() or ROOT.resolve()!=ROOT:raise RuntimeError('Run as root on the identified VPS target')
 if a.rollback:
  if input('Type RESTORE FRONTEND: ')!='RESTORE FRONTEND':raise SystemExit('Canceled')
  restore(a.rollback);return
 expected=json.loads((HERE/'expected_source.json').read_text());source={};meta={}
 for name,sha in expected.items():
  q=ROOT/name
  if q.is_symlink() or not q.is_file():raise RuntimeError('Unsafe/missing source '+name)
  raw=q.read_bytes()
  if digest(raw)!=sha:raise RuntimeError('Source changed since uploaded archive: '+name)
  source[name]=raw
  s=q.stat();meta[name]={'sha':sha,'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode)}
 server=ROOT/'server.py'
 if server.is_symlink() or not server.is_file():raise RuntimeError('Unexpected server.py')
 serverhash=digest(server.read_bytes());tree=ast.parse(server.read_text())
 handler=next((n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Handler'),None)
 if handler is None:raise RuntimeError('Expected bridge Handler absent')
 auth=next((n for n in handler.body if isinstance(n,ast.FunctionDef) and n.name=='authorized'),None)
 if auth and len(auth.body)==1 and isinstance(auth.body[0],ast.Return) and isinstance(auth.body[0].value,ast.Constant) and auth.body[0].value.value is True:
  print('SECURITY WARNING: dashboard login bypass remains. Use only approved private/SSH access; do not expose this bridge.')
 for name in expected:
  if served(name)!=source[name]:raise RuntimeError('Port 8088/source mismatch: '+name)
 payload={'index.html':(HERE/'new_index.html').read_bytes(),'styles.css':source['styles.css']+b'\n'+(HERE/'theme_append.css').read_bytes(),'app.js':source['app.js']+b'\n'+(HERE/'app_append.js').read_bytes()}
 for name in TARGETS:print(str(ROOT/name)+' | original '+digest(source[name])[:16]+' | candidate '+digest(payload[name])[:16])
 print('Preserved byte-for-byte: configurations.js, metrics.js, integrations.js, connections.js. Original app.js and styles.css retained as prefixes.')
 print('No bot/server/backend/auth/state change or restart. Existing settings, request-control and review confirmations retained; real runtime control is NOT newly implemented.')
 if not a.apply:print('CHECK PASSED. Nothing changed.');return
 if not os.isatty(0):raise RuntimeError('Interactive confirmation required')
 if input('Type INSTALL PRESERVING FRONTEND to replace exactly three assets: ')!='INSTALL PRESERVING FRONTEND':raise SystemExit('Canceled')
 for name,sha in expected.items():
  if (ROOT/name).is_symlink() or digest((ROOT/name).read_bytes())!=sha:raise RuntimeError('Source changed during confirmation')
 if digest(server.read_bytes())!=serverhash:raise RuntimeError('Server changed during confirmation')
 if BACKUPS.is_symlink():raise RuntimeError('Unsafe backup root')
 BACKUPS.mkdir(parents=True,mode=0o700,exist_ok=True)
 if BACKUPS.stat().st_uid!=0 or stat.S_IMODE(BACKUPS.stat().st_mode)!=0o700:raise RuntimeError('Backup root must be root-owned 0700')
 backup=Path(tempfile.mkdtemp(prefix='frontend-',dir=BACKUPS));os.chmod(backup,0o700)
 for name in TARGETS:(backup/name).write_bytes(source[name]);os.chmod(backup/name,0o600)
 (backup/'manifest.json').write_text(json.dumps({n:meta[n] for n in TARGETS},indent=2));os.chmod(backup/'manifest.json',0o600)
 guard={n:digest(v) for n,v in payload.items()}
 try:
  for name in ('styles.css','app.js','index.html'):atomic(name,payload[name],meta[name])
  for name in expected:
   wanted=payload.get(name,source[name])
   if (ROOT/name).read_bytes()!=wanted or served(name)!=wanted:raise RuntimeError('Post-install verification failed: '+name)
  if digest(server.read_bytes())!=serverhash:raise RuntimeError('Server changed externally during install')
  print('FRONTEND ASSETS INSTALLED AND VERIFIED OVER LOOPBACK HTTP. No restart performed. Browser/API behavior still requires validation.')
  print('Backup:',backup);print('Rollback: use this installer with --rollback',backup)
 except BaseException:
  print('Verification failed; attempting guarded frontend rollback.');restore(backup,guard);raise
if __name__=='__main__':
 try:main()
 except Exception as e:raise SystemExit('STOPPED: '+str(e))
