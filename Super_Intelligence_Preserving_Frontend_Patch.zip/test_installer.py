import contextlib,importlib.util,io,json,os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('i',Path(__file__).parent/'install_preserving.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class InstallerTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.root=Path(self.t.name)/'root';self.root.mkdir();self.src=Path(self.t.name)/'src';self.src.mkdir();self.backups=Path(self.t.name)/'backups';m.ROOT=self.root;m.BACKUPS=self.backups;m.HERE=self.src
  self.original={n:('original '+n).encode() for n in ('index.html','styles.css','app.js','configurations.js','metrics.js','integrations.js','connections.js')}
  for n,d in self.original.items():(self.root/n).write_bytes(d)
  self.server='class Handler:\n def authorized(self):\n  return True\n'
  (self.root/'server.py').write_text(self.server)
  (self.src/'expected_source.json').write_text(json.dumps({n:m.digest(d) for n,d in self.original.items()}))
  for n,d in [('new_index.html','new shell'),('theme_append.css','new CSS'),('app_append.js','new hooks')]: (self.src/n).write_text(d)
 def tearDown(self):self.t.cleanup()
 def run_main(self,args,answer='INSTALL PRESERVING FRONTEND',served=None):
  with patch.object(sys,'argv',['install']+args),patch('builtins.input',side_effect=answer if callable(answer) else lambda _:answer),patch.object(m.os,'isatty',return_value=True),patch.object(m,'served',side_effect=served or (lambda n:(self.root/n).read_bytes())),contextlib.redirect_stdout(io.StringIO()):m.main()
 def test_check_no_changes(self):
  self.run_main(['--check']);self.assertFalse(self.backups.exists())
  for n,d in self.original.items():self.assertEqual((self.root/n).read_bytes(),d)
 def test_changed_source_blocks(self):
  (self.root/'metrics.js').write_text('other edit')
  with self.assertRaises(RuntimeError):self.run_main(['--apply'])
  self.assertFalse(self.backups.exists())
 def test_install_preserves_original_code_and_helpers(self):
  self.run_main(['--apply']);self.assertTrue((self.root/'app.js').read_bytes().startswith(self.original['app.js']));self.assertTrue((self.root/'styles.css').read_bytes().startswith(self.original['styles.css']))
  for n in ('configurations.js','metrics.js','integrations.js','connections.js'):self.assertEqual((self.root/n).read_bytes(),self.original[n])
  self.assertEqual((self.root/'server.py').read_text(),self.server)
 def test_cancel_does_not_write(self):
  with self.assertRaises(SystemExit):self.run_main(['--apply'],answer='NO')
  self.assertFalse(self.backups.exists())
 def test_rollback_restores(self):
  self.run_main(['--apply']);folder=next(self.backups.iterdir());self.run_main(['--rollback',str(folder)],answer='RESTORE FRONTEND')
  for n,d in self.original.items():self.assertEqual((self.root/n).read_bytes(),d)
 def test_served_failure_rolls_back(self):
  calls={n:0 for n in self.original}
  def served(n):
   calls[n]+=1;return b'WRONG' if calls[n]>1 else (self.root/n).read_bytes()
  with self.assertRaises(RuntimeError):self.run_main(['--apply'],served=served)
  for n,d in self.original.items():self.assertEqual((self.root/n).read_bytes(),d)
 def test_symlink_source_rejected(self):
  p=self.root/'app.js';p.unlink();p.symlink_to(self.src/'app_append.js')
  with self.assertRaises(RuntimeError):self.run_main(['--check'])
if __name__=='__main__':unittest.main(verbosity=2)
