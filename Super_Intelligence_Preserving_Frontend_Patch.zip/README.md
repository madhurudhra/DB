# Super Intelligence — feature-preserving frontend shell repair

## Exact source inspected
GitHub archive: si-current-frontend-20261027T180543934995Z.zip.
Git blob SHA: 3b83fb865e8c89a7364280a0e02cefd6e04c30f5.
The archive contains seven frontend files and frontend-manifest.json. Expected hashes are recorded in expected_source.json.

## Root cause found
The archived index.html is the same 12,012-byte hard-coded HTML previously attached. Its SHA-256 is 2c3b62c80d8307a357fd1d7640f86e1185e179511efc9f64f52ec3b0d6396f9c.
It contains one inline polling script and does NOT load app.js/configurations.js/metrics.js/integrations.js/connections.js. It lacks the 31 named DOM elements the app needs (pageContent, dialogs, fields, refresh buttons, etc.). The existing bridge CSP disallows that inline script.
Therefore the presence of the richer API-connected scripts on disk did not make that HTML use them. This is a confirmed source mismatch, not a claim about actual bot trading status.

## Repair strategy — preserve instead of replacing working code
- Replace index.html with a Super Intelligence shell providing every required DOM ID, navigation, configuration form, review form and correct external-script dependency order.
- Keep the original app.js bytes intact as a prefix; append a DOMContentLoaded hook adding four portfolio cards, selected-bot event filtering and positive/negative ticker rows.
- Keep original styles.css bytes intact as a prefix; append an original dark-forest brokerage-style skin.
- Leave configurations.js, metrics.js, integrations.js and connections.js byte-for-byte unchanged and load all of them.
- Preserve existing configuration saving/confirmations, requested-control saving/warnings, review-only flow, exports, valuation tables, API integrations and connection probes. These are preserved frontend capabilities, NOT proof the backend actions are effective.
- No new POST/PATCH/broker tool is added by the addon. Existing saved-setting/control/review functions retain their confirmation and backend validation.

## Source-backed data rules
Total limit is the configured capital amount, not proof of funded/enforced capital.
Available/invested use verified capital snapshot amounts only when reservation_checks_ready=true and as_of is not future/stale (60-second window matching the existing frontend).
Net unrealized P&L needs complete row coverage and a recent valuation (180-second UI display limit). Missing fee/cost data remains unavailable.
No hard-coded balances, quotes, historical orders, P&L, reserve percentages or strategy approvals are inserted.
Bull/Bear rows use actual normalized market-feed change_percent and valid price. Price-only quotes or missing feed are not assigned a direction. The backend market feed in the supplied output is unavailable; this patch does not invent it.
Events filter the actual bot_name field, not a guessed field. This is an audit feed, not complete process stdout/stderr logs.
Runtime and Auto Trade remain unverified where the backend supplies no actual heartbeat/effective-state evidence. A shared service being active is not treated as independent bot health. Existing execution-enforced runtime buttons remain disabled where their implementation is unavailable.

## Installation safeguards
install_preserving.py defaults to CHECK ONLY; requires root on the identified VPS.
It verifies all seven original source hashes, checks that localhost:8088 serves those exact files, and aborts on mismatches/symlinks rather than overwrite later edits.
Apply requires typing INSTALL PRESERVING FRONTEND. It changes ONLY index.html, styles.css and app.js and creates private backups. It rechecks the source after confirmation, verifies served bytes after install and attempts guarded rollback on failure.
server.py, /opt/super-intelligence, all bot scripts/state/credentials, backend APIs and services are NOT changed or restarted.
The supplied bridge reads assets for every GET, so this static replacement does not require restarting the bot or bridge. Three file replacements are individually atomic, not a single cross-file transaction; a reload during the brief update can see mixed assets. Use an appropriate UI maintenance window.
Rollback: same installer with --rollback followed by its printed backup directory; explicit RESTORE FRONTEND confirmation is required. Review intervening edits first.

## Security issue remains separate
The supplied bridge's authorized() returns True. This frontend patch does not fix that bypass, configure authentication or expose ports. Use only a verified private/SSH access path. Do not publish the bridge or assume it is authenticated. A separate reviewed auth/proxy change is required before public use.

## Tests actually run
- 17 Node addon-model tests: unknown/zero distinction, freshness/future timestamps, capital gating, complete net totals and event scope.
- 7 installer tests using temporary directories and mocked HTTP: no-change check, exact-source guard, preserved original prefixes/helpers, cancel, rollback, verification-failure rollback and symlink refusal.
- Python/JavaScript syntax and static HTML checks: 31 original required IDs, unique IDs, correct external script order, no inline script/handler, no prefilled configuration defaults.
- Isolated browser smoke using the archived ORIGINAL scripts in an equivalent test DOM, with ALL backend fetch calls mocked to 503: no script errors; 16 mocked read calls and zero writes; decimal validation succeeded; configuration popup opened with synthetic configuration and canceled; page and ticker shelf initialized.
Not run: actual final-theme visual/browser regression, live private backend validation, real configuration saves, broker review, actual VPS installation or bot behavior tests. The isolated test is not full live acceptance.

## How to stage
Upload this patch ZIP to the VPS under a NEW name; do not overwrite the old read-only candidate ZIP or source archive.
Extract into a new directory and run install_preserving.py --check. Apply only after reviewing its output and these limitations.
No original archived secrets/server credentials are included in this patch package; it uses originals already on your VPS. Review all private source before publishing.
